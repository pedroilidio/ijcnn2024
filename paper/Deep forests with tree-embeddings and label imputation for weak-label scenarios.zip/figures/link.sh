#!/env/bin bash
set -e

printf -v FILES "%s " \
    ../statistical_comparisons/no_drop/best_level/all_datasets/boxplots/* \
    ../statistical_comparisons/no_drop/level_with_best_oob_score/all_datasets/boxplots/* \
    \
    ../statistical_comparisons/drop50/best_level/all_datasets/boxplots/* \
    ../statistical_comparisons/drop50/level_with_best_oob_score/all_datasets/boxplots/* \
    \
    ../statistical_comparisons/drop70/best_level/all_datasets/boxplots/* \
    ../statistical_comparisons/drop70/level_with_best_oob_score/all_datasets/boxplots/* \
    \
    ../statistical_comparisons/drop90/best_level/all_datasets/boxplots/* \
    ../statistical_comparisons/drop90/level_with_best_oob_score/all_datasets/boxplots/* \
    \
    ../level_comparison/cascade_lc_tree_embedder_proba__50/average_precision_micro.png \
    ../level_comparison/cascade_lc_tree_embedder_proba__50/roc_auc_micro.png \
    ../level_comparison/cascade_scar_tree_embedder_proba__50/average_precision_micro.png \
    ../level_comparison/cascade_scar_tree_embedder_proba__50/roc_auc_micro.png \
    ../level_comparison/cascade_tree_embedder_proba__50/average_precision_micro.png \
    ../level_comparison/cascade_tree_embedder_proba__50/roc_auc_micro.png \
    \

for FILE in ${FILES[@]}
    do ln -sr $FILE  $(echo $FILE | sed "s/\.\.\///g" | sed "s/\//__/g")
done
